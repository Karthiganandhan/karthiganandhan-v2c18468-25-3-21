public class Daemonex extends Thread
{  
 public void run()
 {  
  if(Thread.currentThread().isDaemon())
  {
	  //checking for daemon thread  
   System.out.println("daemon thread work");  
  }  
  else
  {  
  System.out.println("user thread work");  
 }  
 }  
 public static void main(String[] args)
 {  
	 Daemonex t1=new Daemonex();
	 Daemonex t2=new Daemonex();  
	 Daemonex t3=new Daemonex();  
  
  t1.setDaemon(true);//t1 is daemon thread  
    
  //starting threads  
  t2.start();  
  t3.start();
  t1.start();
 // t1.setDaemon(true);//t1 is daemon thread(throw exception must not be started a thread before setdaemon  
  
 }  
}  